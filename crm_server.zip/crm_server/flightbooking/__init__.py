default_app_config = 'flightbooking.apps.FlightbookingConfig'
