from django.apps import AppConfig


class FlightbookingConfig(AppConfig):
    name = 'flightbooking'

    def ready(self):
        pass