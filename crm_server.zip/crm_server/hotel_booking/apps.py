from django.apps import AppConfig


class HotelbookingConfig(AppConfig):
    name = 'hotelbooking'
