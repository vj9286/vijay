from django.apps import AppConfig


class CarbookingConfig(AppConfig):
    name = 'carbooking'
