default_app_config = 'bookings.apps.BookingsConfig'
