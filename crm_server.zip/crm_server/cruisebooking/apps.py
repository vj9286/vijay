from django.apps import AppConfig


class CruisebookingConfig(AppConfig):
    name = 'cruisebooking'
