from django.apps import AppConfig


class TourbookingConfig(AppConfig):
    name = 'tourbooking'
